<?php
wp_enqueue_style( 'style-name', get_stylesheet_uri() );
wp_enqueue_style( 'style-boot', get_template_directory_uri() . '/asset/css/bootstrap.min.css' );
wp_enqueue_script( 'script-name', get_template_directory_uri() . '/asset/js/bootstrap.bundle.min.js', array(), '1.0.0', true );

add_theme_support( 'title-tag' );
add_theme_support( 'custom-logo' );
add_theme_support( 'post-thumbnails' );

register_nav_menus([
    'TM' => 'primary menu'
]);

register_sidebar([
    'name' => 'menu bar',
    'id' => 'menubar',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'search bar',
    'id' => 'searchbar',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'banner',
    'id' => 'banner',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'minister img',
    'id' => 'mini_img',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'minister content',
    'id' => 'mini_content',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'card 1 img',
    'id' => 'card_1_img',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'card 1 text',
    'id' => 'card_1_text',
    'before_widget' => '',
    'after_widget' => ''
]);



register_sidebar([
    'name' => 'card right img 1',
    'id' => 'card_right_img_1',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'card right text 1',
    'id' => 'card_right_text_1',
    'before_widget' => '',
    'after_widget' => ''
]);



// left card
register_sidebar([
    'name' => 'card left img 2',
    'id' => 'card_left_img_2',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'card left text 2',
    'id' => 'card_left_text_2',
    'before_widget' => '',
    'after_widget' => ''
]);



// right card
register_sidebar([
    'name' => 'card right img 2',
    'id' => 'card_right_img_2',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'card right text 2',
    'id' => 'card_right_text_2',
    'before_widget' => '',
    'after_widget' => ''
]);





// left card 3------------------------------------------
register_sidebar([
    'name' => 'card left img 3',
    'id' => 'card_left_img_3',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'card left text 3',
    'id' => 'card_left_text_3',
    'before_widget' => '',
    'after_widget' => ''
]);



// right card 3-----------------------------------------
register_sidebar([
    'name' => 'card right img 3',
    'id' => 'card_right_img_3',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'card right text 3',
    'id' => 'card_right_text_3',
    'before_widget' => '',
    'after_widget' => ''
]);




// left card 4------------------------------------------
register_sidebar([
    'name' => 'card left img 4',
    'id' => 'card_left_img_4',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'card left text 4',
    'id' => 'card_left_text_4',
    'before_widget' => '',
    'after_widget' => ''
]);



// right card 4-----------------------------------------
register_sidebar([
    'name' => 'card right img 4',
    'id' => 'card_right_img_4',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'card right text 4',
    'id' => 'card_right_text_4',
    'before_widget' => '',
    'after_widget' => ''
]);




// left card 5------------------------------------------
register_sidebar([
    'name' => 'card left img 5',
    'id' => 'card_left_img_5',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'card left text 5',
    'id' => 'card_left_text_5',
    'before_widget' => '',
    'after_widget' => ''
]);



// right card 5-----------------------------------------
register_sidebar([
    'name' => 'card right img 5',
    'id' => 'card_right_img_5',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'card right text 5',
    'id' => 'card_right_text_5',
    'before_widget' => '',
    'after_widget' => ''
]);



// left card 6------------------------------------------
register_sidebar([
    'name' => 'card left img 6',
    'id' => 'card_left_img_6',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'card left text 6',
    'id' => 'card_left_text_6',
    'before_widget' => '',
    'after_widget' => ''
]);



// right card 6-----------------------------------------
register_sidebar([
    'name' => 'card right img 6',
    'id' => 'card_right_img_6',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'card right text 6',
    'id' => 'card_right_text_6',
    'before_widget' => '',
    'after_widget' => ''
]);



// sidebar start


register_sidebar([
    'name' => 'sidebar 1',
    'id' => 'sidebar_1',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'sidebar 2',
    'id' => 'sidebar_2',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'sidebar 3',
    'id' => 'sidebar_3',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'sidebar 4',
    'id' => 'sidebar_4',
    'before_widget' => '',
    'after_widget' => ''
]);



register_sidebar([
    'name' => 'policy rate',
    'id' => 'policy_rate',
    'before_widget' => '',
    'after_widget' => ''
]);


register_sidebar([
    'name' => 'footer left',
    'id' => 'footer_left',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'footer middle',
    'id' => 'footer_middle',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'footer right',
    'id' => 'footer_right',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'footer bottom',
    'id' => 'footer_bottom',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'footer bottom text',
    'id' => 'footer_bottom_text',
    'before_widget' => '',
    'after_widget' => ''
]);

?>