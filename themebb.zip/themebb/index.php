<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bangladesh Bank</title>
    <?php wp_head(); ?>
</head>
<body>
    <!-- header part -->
    <section class="cont">
        <div class="header_topBar">
            <div class="row">
                <div class="col-lg-2 menuBar">
                    <?php dynamic_sidebar('menubar') ?>
                </div>
                <div class="col-lg-8 searchBar">
                    <?php dynamic_sidebar('searchbar') ?>
                    <!-- <input type="text" class="block_input" aria-label="Search" placeholder="Search" ><i class="fa-solid fa-magnifying-glass block_icons"></i> -->
                </div>
                <div class="col-lg-2 languageTxt text-center">
                    <p>বাংলা</p>
                </div>
            </div>
        </div>
    </section>

    <!-- banner part -->
    <section class="cont">
        <div class="banner">
            <?php dynamic_sidebar('banner') ?>
        </div>
    </section>

    <!-- menu part -->
    <section class="cont">
        <div class="menu">
            <div class="row">
                <div class="col-lg-6 menu_left"></div>
                <div class="col-lg-6 menu_right">
                <?php
                    wp_nav_menu([
                        'menu_locations' => 'TM',
                        'menu_class' => 'navbar menu'
                    ]);
                    
                    ?>
                </div>
            </div>
           
        </div>
    </section>

    <!-- hero part -->
    <section class="cont ">
        <div class="hero ">
            <div class="row">

                <div class="col-lg-8 slider mt-2 text-center">
                <div id="carouselExample" class="carousel slide">
                    <div class="carousel-inner">
                        <?php
                        $x = 0;
                        while (have_posts()){the_post();
                        $x++;                        
                        ?>
                        <div class="carousel-item <?= ($x==1)? 'active': '' ?> ">
                        <?php the_post_thumbnail(); ?>
                        <!-- <img src="..." class="d-block w-100" alt="..."> -->
                        </div>
                        <?php } ?>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                    </div>
                </div>

                <div class="col-lg-4 minister mt-2">

                    <div class="governore_card">
                    <div class="mini_title">
                        <p>HONORABLE GOVERNOR</p>
                    </div>


                    <div class="row mt-2">
                        <div class="col-lg-6 minis_img">
                            <?php dynamic_sidebar('mini_img') ?>                            
                        </div>
                        <div class="col-sm-6 minis_content">
                            <?php dynamic_sidebar('mini_content') ?>
                        </div>
                    </div>

                    </div>
                    
                    
                </div>
            </div>
        </div>
    </section>

    <!-- news part -->
    <section class="cont">
        <div class="news">
            <div class="row mt-3">
                <div class="col-lg-2 fixed_txt">
                    <p>RECENT NEWS</p>
                </div>
                <div class="col-lg-8 content_txt">
                    <p>DOS Circular Letter No. 04: Keeping scheduled bank branches closed in the election area on 01st February 2023 for Election of some National</p>

                </div>
                <div class="col-lg-2 fixed_arrow"></div>
            </div>
        </div>
    </section>

    <!-- hero part -->
    <section class="cont">
        <div class="hero_main_body">
            <div class="row">
                <div class="col-lg-8 body">
        <!-- ---------------------card 1 start-------------------------- -->
                    <div class="row">                        
                        <div class="col-lg-6  mt-5" >  

                            <div class="card_left">
                                <h6>MONETARY POLICY</h6>
                                <div class="row mt-2">
                                    <div class="col-lg-4">
                                        <?php dynamic_sidebar('card_1_img') ?>
                                    </div>
                                    <div class="col-lg-8">
                                        <?php dynamic_sidebar('card_1_text') ?> 
                                    </div>
                                </div>
                            </div>                          
                            
                        </div>

                        <div class="col-lg-6  mt-5">
                            <div class="card_rightt">
                            <h6>MEDIA & PRESS RELEASE</h6>
                                <div class="row mt-2">
                                    <div class="col-lg-4">
                                        <?php dynamic_sidebar('card_right_img_1') ?>
                                    </div>
                                    <div class="col-lg-8">
                                        <?php dynamic_sidebar('card_right_text_1') ?> 
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                
        <!-- ---------------------card 1 end -------------------------- -->
        <!-- ---------------------card 2 start-------------------------- -->

        <div class="row">                        
                        <div class="col-lg-6  mt-3" >  

                            <div class="card_left">
                                <h6>INVESTMENT FACILITY</h6>
                                <div class="row mt-2">
                                    <div class="col-lg-4">
                                        <?php dynamic_sidebar('card_left_img_2') ?>
                                    </div>
                                    <div class="col-lg-8">
                                        <?php dynamic_sidebar('card_left_text_2') ?> 
                                    </div>
                                </div>
                            </div>                          
                            
                        </div>

                        <div class="col-lg-6  mt-3">
                            <div class="card_rightt">
                            <h6>GOVERNMENT SECURITIES</h6>
                                <div class="row mt-2">
                                    <!-- <div class="col-lg-4">
                                        <?php dynamic_sidebar('card_right_img_2') ?>
                                    </div> -->
                                    <div >
                                        <?php dynamic_sidebar('card_right_text_2') ?> 
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
        <!-- ---------------------card 2 end-------------------------- -->

        <!-- ---------------------card 3 start-------------------------- -->
                    <div class="row">                        
                        <div class="col-lg-6  mt-3" >  

                            <div class="card_left">
                                <h6>SERVICES</h6>
                                <div class="row mt-2">
                                    <div class="col-lg-4">
                                        <?php dynamic_sidebar('card_left_img_3') ?>
                                    </div>
                                    <div class="col-lg-8">
                                        <?php dynamic_sidebar('card_left_text_3') ?> 
                                    </div>
                                </div>
                            </div>                          
                            
                        </div>

                        <div class="col-lg-6  mt-3">
                            <div class="card_rightt">
                            <h6>ECONOMIC DATA</h6>
                                <div class="row mt-2">
                                    <div class="col-lg-4">
                                        <?php dynamic_sidebar('card_right_img_3') ?>
                                    </div>
                                    <div class="col-lg-8">
                                        <?php dynamic_sidebar('card_right_text_3') ?> 
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
        <!-- ---------------------card 3 end-------------------------- -->


        <!-- ---------------------card 4 start-------------------------- -->
                    <div class="row">                        
                        <div class="col-lg-6  mt-3" >  

                            <div class="card_left">
                                <h6>INNOVATION CORNER</h6>
                                <div class="row mt-2">
                                    <div class="col-lg-4">
                                        <?php dynamic_sidebar('card_left_img_4') ?>
                                    </div>
                                    <div class="col-lg-8">
                                        <?php dynamic_sidebar('card_left_text_4') ?> 
                                    </div>
                                </div>
                            </div>                          
                            
                        </div>

                        <div class="col-lg-6  mt-3">
                            <div class="card_rightt">
                            <h6>NATIONAL INTEGRITY STRATEGY</h6>
                                <div class="row mt-2">
                                    <!-- <div class="col-lg-4">
                                        <?php dynamic_sidebar('card_right_img_4') ?>
                                    </div> -->
                                    <div>
                                        <?php dynamic_sidebar('card_right_text_4') ?> 
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
        <!-- ---------------------card 4 end-------------------------- -->


        <!-- ---------------------card 5 start-------------------------- -->
                    <div class="row">                        
                        <div class="col-lg-6  mt-3" >  

                            <div class="card_left">
                                <h6>CITIZEN CHARTER</h6>
                                <div class="row mt-2">
                                    
                                    <div>
                                        <?php dynamic_sidebar('card_left_text_5') ?> 
                                    </div>
                                </div>
                            </div>                          
                            
                        </div>

                        <div class="col-lg-6  mt-3">
                            <div class="card_rightt">
                            <h6>NATIONAL ICT POLICY 2018</h6>
                                <div class="row mt-2">
                                    
                                    <div>
                                        <?php dynamic_sidebar('card_right_text_5') ?> 
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
        <!-- ---------------------card 5 end-------------------------- -->




        <!-- ---------------------card 6 start-------------------------- -->

                    <div class="row">                        
                        <div class="col-lg-6  mt-3" >  

                            <div class="card_left">
                                <h6>LINKS</h6>
                                <div class="row mt-2">
                                    <div class="col-lg-4">
                                        <?php dynamic_sidebar('card_left_img_6') ?>
                                    </div>
                                    <div class="col-lg-8">
                                        <?php dynamic_sidebar('card_left_text_6') ?> 
                                    </div>
                                </div>
                            </div>                          
                            
                        </div>

                        <div class="col-lg-6  mt-3">
                            <div class="card_rightt">
                            <h6>RECENT UPLOAD</h6>
                                <div class="row mt-2">
                                    <div class="col-lg-4">
                                        <?php dynamic_sidebar('card_right_img_6') ?>
                                    </div>
                                    <div class="col-lg-8">
                                        <?php dynamic_sidebar('card_right_text_6') ?> 
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
        <!-- ---------------------card 6 end-------------------------- -->

        <section class="policy_rate">
            <div class="row">
                <div class="col-lg-4 policy_left mt-3">
                    <?php dynamic_sidebar('policy_rate') ?>
                </div>
                <div class="col-lg-4 policy_midle mt-3">
                <?php dynamic_sidebar('policy_rate') ?>

                </div>
                <div class="col-lg-4 policy_right mt-3">
                <?php dynamic_sidebar('policy_rate') ?>

                </div>
            </div>
        </section>



                </div>



                <div class="col-lg-4 sidebar mt-5">
                    <div class="sidebar_main">
                        <div class="sidebar_card">
                        <?php dynamic_sidebar('sidebar_1') ?>
                        </div>
                    </div>

                    <div class="sidebar_main">
                        <div class="sidebar_card">
                        <?php dynamic_sidebar('sidebar_2') ?>
                        </div>
                    </div>


                    <div class="sidebar_main">
                        <div class="sidebar_card line_bar">
                        <?php dynamic_sidebar('sidebar_3') ?>
                        </div>
                    </div>


                    <div class="sidebar_main">
                        <div class="sidebar_card line_bar_1 ">
                        <?php dynamic_sidebar('sidebar_4') ?>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </section>

    <!-- footer part -->
    <footer class="cont mt-3">
        <div class="footer_main mt-4">
            <div class="row">
                <div class="col-lg-4 footer_left">
                    <?php dynamic_sidebar('footer_left') ?>
                </div>
                <div class="col-lg-4 footer_middle">
                <?php dynamic_sidebar('footer_middle') ?>

                </div>
                <div class="col-lg-4 footer_right">
                <?php dynamic_sidebar('footer_right') ?>

                <i class="fa-brands fa-2x fa-facebook"></i>
                <i class="fa-brands fa-2x fa-twitter"></i>
                <i class="fa-brands fa-2x fa-youtube"></i>


                </div>
            </div>
                    <div class="footer_bottom_link mt-3">
                        <?php dynamic_sidebar('footer_bottom') ?>
                    </div>

                    <div class="footer_bottom mt-3">
                        <?php dynamic_sidebar('footer_bottom_text') ?>
                    </div>

        </div>
    </footer>
    

<?php wp_footer(); ?>
</body>
</html>